/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIOImp {
	/**
	 * ���ļ�
	 * 
	 * @param FILEPATH
	 * @param filename
	 * @return
	 */
	public static String read(String FILEPATH, String filename) {
		String fileString = "";
		String lineString = "";
		try {
			// �������System.out.println("�ļ���"+filename);
			File file = new File(FILEPATH + filename);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			while ((lineString = br.readLine()) != null) {
				fileString += lineString + "\n";
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fileString;
	}

	/**
	 * д�ļ�
	 * 
	 * @param FILEPATH
	 * @param data
	 * @param mode
	 * @param filename
	 */
	public static void write(String FILEPATH, String data, boolean mode, String filename) {
		try {
			// System.out.println("�Ƿ�����˸���д��");//����
			File file = new File(FILEPATH + filename);
			FileWriter fw = new FileWriter(file, mode);
			fw.write(data);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
